package com.example.bookshop.customer;

public class CustomerService {

}
