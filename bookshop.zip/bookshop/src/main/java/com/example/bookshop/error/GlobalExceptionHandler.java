package com.example.bookshop.error;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@ControllerAdvice
public class GlobalExceptionHandler {

    @Value("${spring.profiles.active:default}")
    private String activeProfile;

    private String getStackTraceAsString(Exception ex) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        ex.printStackTrace(pw);
        return sw.toString();
    }

    @ExceptionHandler(NoResourceFoundException.class)
    public ModelAndView handleNoResourceFoundException(NoResourceFoundException ex, Model model) {
        ModelAndView mav = new ModelAndView("error");

        if ("dev".equals(activeProfile)) {
            // Provide detailed error information in development mode
            mav.addObject("errorMessage", ex.getMessage());
            mav.addObject("stackTrace", getStackTraceAsString(ex)); // Include stack trace for debugging
            mav.addObject("errorType", "Resource Not Found");
            mav.addObject("httpStatus", HttpStatus.NOT_FOUND.value());
        } else {
            // Provide generic error information in production mode
            mav.addObject("errorMessage", "The requested resource was not found.");
            mav.addObject("errorType", "Resource Not Found");
            mav.addObject("httpStatus", HttpStatus.NOT_FOUND.value());
        }

        return mav;
    }

    @ExceptionHandler(Exception.class)
    public ModelAndView handleException(Exception ex, Model model) {
        ModelAndView mav = new ModelAndView("error");

        if ("dev".equals(activeProfile)) {
            // Provide detailed error information in development mode
            mav.addObject("errorMessage", ex.getMessage());
            mav.addObject("stackTrace", getStackTraceAsString(ex)); // Include stack trace for debugging
            mav.addObject("errorType", "Unexpected Error");
            mav.addObject("httpStatus", HttpStatus.INTERNAL_SERVER_ERROR.value());
        } else {
            // Provide generic error information in production mode
            mav.addObject("errorMessage", "An unexpected error occurred. Please try again later.");
            mav.addObject("errorType", "Unexpected Error");
            mav.addObject("httpStatus", HttpStatus.INTERNAL_SERVER_ERROR.value());
        }

        return mav;
    }
}
