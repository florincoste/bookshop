package com.example.bookshop.customer;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.bookshop.auth.AuthService;

import jakarta.servlet.http.HttpSession;

@Controller
public class CustomerController {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private AuthService authService;

    @GetMapping("/login")
    public String loginPage(Model model, HttpSession session) {
        if (authService.isCustomerLoggedIn(session)) {
            return "redirect:/";
        }
        model.addAttribute("loginError", false);
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam String email,
            @RequestParam String password,
            HttpSession session,
            Model model) {
        if (authService.authenticateCustomer(email, password)) {
            authService.setCustomerLogin(session, email);
            return "redirect:/";
        } else {
            model.addAttribute("loginError", true);
            return "login";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        authService.logoutCustomer(session);
        return "redirect:/";
    }

    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    @PostMapping("/register")
    public String processRegistration(@RequestParam String name,
            @RequestParam String surname,
            @RequestParam String dateOfBirth,
            @RequestParam String address,
            @RequestParam String phone,
            @RequestParam String email,
            @RequestParam String password,
            Model model,
            HttpSession session) {
        if (customerRepository.findByEmail(email).isPresent()) {
            model.addAttribute("registrationError", "Email already exists.");
            return "register";
        }

        Customer newCustomer = new Customer();
        newCustomer.setName(name);
        newCustomer.setSurname(surname);
        newCustomer.setDateOfBirth(LocalDate.parse(dateOfBirth));
        newCustomer.setAddress(address);
        newCustomer.setPhone(phone);
        newCustomer.setEmail(email);
        newCustomer.setPassword(password);

        customerRepository.save(newCustomer);

        authService.setCustomerLogin(session, newCustomer.getEmail());

        return "redirect:/";
    }

    @GetMapping("/profile")
    public String viewProfile(Model model, HttpSession session) {
        // Ensure the user is logged in
        if (!authService.isCustomerLoggedIn(session)) {
            return "redirect:/login";
        }
        String email = authService.getLoggedInCustomerEmail(session);
        Customer customer = customerRepository.findByEmail(email).orElse(null);
        if (customer == null) {
            authService.logoutCustomer(session);
            return "redirect:/login";
        }
        model.addAttribute("customer", customer);
        model.addAttribute("orders", customer.getOrders()); // Assuming getOrders() returns List<Order>
        return "profile";
    }

}
