package com.example.bookshop.order;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.bookshop.auth.AuthService;
import com.example.bookshop.cart.Cart;
import com.example.bookshop.cart.CartItem;
import com.example.bookshop.customer.Customer;
import com.example.bookshop.customer.CustomerRepository;
import com.example.bookshop.book.Book;
import com.example.bookshop.book.BookRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class OrderController {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private AuthService authService;

    @Autowired
    private BookRepository bookRepository;

    // Helper method to get the currently logged in customer
    private Customer getLoggedInCustomer(HttpSession session) {
        if (!authService.isCustomerLoggedIn(session)) {
            return null;
        }
        String email = authService.getLoggedInCustomerEmail(session);
        return customerRepository.findByEmail(email).orElse(null);
    }

    // Checkout page section
    @GetMapping("/checkout")
    public String showCheckout(Model model, HttpSession session) {
        if (!authService.isCustomerLoggedIn(session)) {
            return "redirect:/login";
        }
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }
        model.addAttribute("cart", cart);
        return "checkout";
    }

    @PostMapping("/checkout")
    public String postCheckout(
            @RequestParam String cardName,
            @RequestParam String creditCard,
            @RequestParam String expiryMonth,
            @RequestParam String expiryYear,
            @RequestParam String cvv,
            Model model,
            HttpSession session) {

        Customer customer = getLoggedInCustomer(session);
        if (customer == null) {
            return "redirect:/login";
        }

        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null || cart.getItems().isEmpty()) {
            return "redirect:/";
        }

        // Server-side card number validation (16 digits, spaces/dashes allowed)
        String cardPattern = "^(?:\\d{4}[- ]?){3}\\d{4}$";
        if (!creditCard.matches(cardPattern)) {
            model.addAttribute("cart", cart);
            model.addAttribute("error", "Invalid card number format.");
            return "checkout";
        }

        // Server Validation of expiry date and cvv
        if (!expiryMonth.matches("^(0[1-9]|1[0-2])$")) {
            model.addAttribute("cart", cart);
            model.addAttribute("error", "Invalid expiry month format. Use MM.");
            return "checkout";
        }
        if (!expiryYear.matches("^\\d{2}$")) {
            model.addAttribute("cart", cart);
            model.addAttribute("error", "Invalid expiry year format. Use YY.");
            return "checkout";
        }
        if (!cvv.matches("^\\d{3,4}$")) {
            model.addAttribute("cart", cart);
            model.addAttribute("error", "Invalid CVV.");
            return "checkout";
        }

        // Check stock for the books in the cart and update stock
        for (CartItem cartItem : cart.getItems()) {
            Book book = bookRepository.findById(cartItem.getBook().getId()).orElse(null);
            if (book == null) {
                model.addAttribute("cart", cart);
                model.addAttribute("error", "Book not found: " + cartItem.getBook().getTitle());
                return "checkout";
            }
            int newStock = book.getCopies() - cartItem.getQuantity();
            if (newStock < 0) {
                model.addAttribute("cart", cart);
                model.addAttribute("error", "Not enough stock for " + book.getTitle());
                return "checkout";
            }
            book.setCopies(newStock);
            bookRepository.save(book);
        }

        Order order = new Order();
        order.setCustomer(customer);
        order.setPaymentStatus(Order.PaymentStatus.success);
        order.setAmount(cart.getTotalPrice());
        order.setOrderDate(LocalDateTime.now());

        List<OrderItem> orderItems = cart.getItems().stream().map(cartItem -> {
            OrderItem oi = new OrderItem();
            oi.setOrder(order);
            oi.setBook(cartItem.getBook());
            oi.setQuantity(cartItem.getQuantity());
            return oi;
        }).collect(Collectors.toList());
        order.setOrderItems(orderItems);

        orderRepository.save(order);

        // Clear the cart
        cart.clear();
        session.setAttribute("cart", cart);

        return "redirect:/order/success/" + order.getId();
    }

    // Order results redirect
    @GetMapping("/order/success/{orderId}")
    public String orderSuccess(@PathVariable("orderId") Integer orderId,
            Model model,
            HttpSession session) {

        Customer customer = getLoggedInCustomer(session);
        if (customer == null) {
            return "redirect:/login";
        }

        Order order = orderRepository.findById(orderId).orElse(null);

        if(order.getPaymentStatus() != Order.PaymentStatus.success) {
            return "redirect:/order/failed";
        }

        // check if the order does not exist OR if there is a mismatch between the order's customer and the logged-in customer
        if (order == null || !order.getCustomer().getId().equals(customer.getId())) {
            return "redirect:/order/failed?error=Invalid%20order";
        }

        model.addAttribute("customer", customer);
        model.addAttribute("order", order);
        return "order-success";
    }

    @GetMapping("/order/failed")
    public String orderFailed(@RequestParam(value = "error", required = false) String error, Model model) {
        if (error != null) {
            model.addAttribute("error", error);
        }
        return "order-failed";
    }

}
