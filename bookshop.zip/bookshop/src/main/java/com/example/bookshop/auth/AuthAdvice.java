package com.example.bookshop.auth;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import jakarta.servlet.http.HttpSession;

@ControllerAdvice
public class AuthAdvice {

    @ModelAttribute("isAuthenticated")
    public boolean isAuthenticated(HttpSession session) {
        Boolean loggedIn = (Boolean) session.getAttribute("user_logged_in");
        return loggedIn != null && loggedIn;
    }
}