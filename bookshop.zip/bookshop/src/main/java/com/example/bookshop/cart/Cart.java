package com.example.bookshop.cart;

import java.util.ArrayList;
import java.util.List;

public class Cart {

    private List<CartItem> items = new ArrayList<>();

    public List<CartItem> getItems() {
        return items;
    }

    public void setItems(List<CartItem> items) {
        this.items = items;
    }

    public void addItem(CartItem item) {
        // If item for this book exists, increase quantity
        for (CartItem ci : items) {
            if (ci.getBook().getId().equals(item.getBook().getId())) {
                ci.setQuantity(ci.getQuantity() + item.getQuantity());
                return;
            }
        }
        items.add(item);
    }

    public void removeItem(Integer bookId) {
        items.removeIf(ci -> ci.getBook().getId().equals(bookId));
    }

    public void clear() {
        items.clear();
    }

    public double getTotalPrice() {
        return items.stream()
            .mapToDouble(ci -> ci.getBook().getPrice() * ci.getQuantity())
            .sum();
    }

    public int getTotalQuantity() {
        return items.stream().mapToInt(CartItem::getQuantity).sum();
    }

    public void updateItemQuantity(Integer bookId, int quantity) {
        for (CartItem ci : items) {
            if (ci.getBook().getId().equals(bookId)) {
                ci.setQuantity(quantity);
                break;
            }
        }
    }
}