package com.example.bookshop.home;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.bookshop.book.Book;
import com.example.bookshop.book.BookService;

@Controller
public class HomeController {
    private final BookService bookService;

    public HomeController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/")
    public String home(Model model) {
        List<Book> books = bookService.getSellableBooks();
        if (books.isEmpty()) {
            books.add(new Book("No books available", "N/A", 0, 0.0, 0));
        }
        // books.forEach(System.out::println);
        model.addAttribute("books", books);
        return "home";
    }
}
