package com.example.bookshop.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.bookshop.auth.AuthService;
import com.example.bookshop.book.Book;
import com.example.bookshop.book.BookRepository;
import com.example.bookshop.customer.Customer;
import com.example.bookshop.customer.CustomerRepository;
import com.example.bookshop.order.Order;
import com.example.bookshop.order.OrderItemRepository;
import com.example.bookshop.order.OrderRepository;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AuthService authService;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;


    @GetMapping
    public String adminRoot(HttpSession session) {
        if (authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/dashboard";
        } else {
            return "redirect:/admin/login";
        }
    }

    // Admin Login Functionality
    @GetMapping("/login")
    public String loginPage() {
        return "admin/login";
    }

@PostMapping("/login")
    public String processLogin(@RequestParam String username,
            @RequestParam String password,
            HttpSession session,
            Model model) {
        if (authService.authenticateAdmin(username, password)) {
            authService.setAdminLogin(session, username);
            return "redirect:/admin/dashboard";
        } else {
            model.addAttribute("loginError", true);
            return "admin/login";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        authService.logoutAdmin(session);
        return "redirect:/admin/login";
    }

    // Admin Dash 
    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        if (!authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }
        model.addAttribute("books", bookRepository.findAll());
        model.addAttribute("customers", customerRepository.findAll());
        model.addAttribute("orders", orderRepository.findAll());
        return "admin/dashboard";
    }

    // Cust Fucntions
    @GetMapping("/customers/view/{id}")
    public String viewCustomer(@PathVariable Integer id, HttpSession session, Model model) {
        if (!authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }
        Customer customer = customerRepository.findById(id).orElse(null);
        if (customer == null) {
            return "redirect:/admin/dashboard";
        }
        model.addAttribute("customer", customer);
        return "admin/customer-view";
    }

    @GetMapping("/customers/edit/{id}")
    public String editCustomerForm(@PathVariable Integer id, HttpSession session, Model model) {
        if (!authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }
        Customer customer = customerRepository.findById(id).orElse(null);
        if (customer == null) {
            return "redirect:/admin/dashboard";
        }
        model.addAttribute("customer", customer);
        return "admin/customer-edit";
    }

    @PostMapping("/customers/edit/{id}")
    public String editCustomer(@PathVariable Integer id, @ModelAttribute Customer updatedCustomer, HttpSession session) {
        if (!authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }

        Customer existingCustomer = customerRepository.findById(id).orElse(null);
        if (existingCustomer == null || !updatedCustomer.getId().equals(id)) {
            return "redirect:/admin/dashboard";
        }

        updatedCustomer.setId(existingCustomer.getId());
        updatedCustomer.setPassword(existingCustomer.getPassword());

        customerRepository.save(updatedCustomer);
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/customers/delete/{id}")
    public String deleteCustomer(@PathVariable Integer id, HttpSession session, RedirectAttributes attributes) {
        if (!authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }

        Customer customer = customerRepository.findById(id).orElse(null);
        if (customer == null) {
            return "redirect:/admin/dashboard";
        }

        if (customer.getOrders() != null && !customer.getOrders().isEmpty()) {
            attributes.addFlashAttribute("Error", "Cannot delete customer with existing orders.");
            return "redirect:/admin/dashboard";
        }

        customerRepository.deleteById(id);
        return "redirect:/admin/dashboard";
    }

    //Book Functions
    @GetMapping("/books/add")
    public String addBookForm(HttpSession session, Model model) {
        if (!authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }
        model.addAttribute("book", new Book());
        return "admin/book-add";
    }

    @PostMapping("/books/add")
    public String addBook(@ModelAttribute Book book, HttpSession session) {
        if (!authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }
        bookRepository.save(book);
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/books/edit/{id}")
    public String editBookForm(@PathVariable Integer id, HttpSession session, Model model) {
        if (!authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }
        Book book = bookRepository.findById(id).orElse(null);
        if (book == null) {
            return "redirect:/admin/dashboard";
        }
        model.addAttribute("book", book);
        return "admin/book-edit";
    }

    @PostMapping("/books/edit/{id}")
    public String editBook(@PathVariable Integer id, @ModelAttribute Book book, HttpSession session) {
        if (!authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }
        book.setId(id);
        bookRepository.save(book);
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/books/delete/{id}")
    public String deleteBook(@PathVariable Integer id, HttpSession session, RedirectAttributes attributes) {
        if (!authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }

        Book book = bookRepository.findById(id).orElse(null);
        if (book == null) {
            attributes.addFlashAttribute("Error", "Book not found.");
            return "redirect:/admin/dashboard";
        }

        if (orderItemRepository.existsByBook_Id(id)) {
            attributes.addFlashAttribute("Error", "Cannot delete book that is part of existing orders.");
            return "redirect:/admin/dashboard";
        }

        bookRepository.deleteById(id);
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/books/publish/{id}")
    public String publishBook(@PathVariable Integer id, HttpSession session) {
        if (!authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }
        Book book = bookRepository.findById(id).orElse(null);
        if (book != null) {
            book.setSellable(true);
            bookRepository.save(book);
        }
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/books/archive/{id}")
    public String archiveBook(@PathVariable Integer id, HttpSession session) {
        if (!authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }
        Book book = bookRepository.findById(id).orElse(null);
        if (book != null) {
            book.setSellable(false);
            bookRepository.save(book);
        }
        return "redirect:/admin/dashboard";
    }

    // Order Functions    
    @GetMapping("/orders/view/{id}")
    public String viewOrder(@PathVariable Integer id, HttpSession session, Model model) {
        if (!authService.isAdminLoggedIn(session)) {
            return "redirect:/admin/login";
        }
        Order order = orderRepository.findById(id).orElse(null);
        if (order == null) {
            return "redirect:/admin/dashboard";
        }
        model.addAttribute("order", order);
        model.addAttribute("items", order.getOrderItems());
        return "admin/order-view";
    }

}
