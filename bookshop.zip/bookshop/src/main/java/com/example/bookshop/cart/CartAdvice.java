package com.example.bookshop.cart;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import jakarta.servlet.http.HttpSession;

@ControllerAdvice
public class CartAdvice {

    @ModelAttribute("cartCount")
    public int cartCount(HttpSession session) {
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) return 0;
        return cart.getTotalQuantity();
    }
}