package com.example.bookshop.cart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.bookshop.auth.AuthService;
import com.example.bookshop.book.Book;
import com.example.bookshop.book.BookRepository;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private AuthService authService;

    @GetMapping
    public String viewCart(HttpSession session, Model model) {
        if (!authService.isCustomerLoggedIn(session)) {
            return "redirect:/login";
        }
        Cart cart = getCart(session);
        model.addAttribute("cart", cart);
        return "cart";
    }

    @PostMapping("/add/{bookId}")
    public String addToCart(@PathVariable Integer bookId, HttpSession session) {
        if (!authService.isCustomerLoggedIn(session)) {
            return "redirect:/login";
        }
        Book book = bookRepository.findById(bookId).orElse(null);
        if (book == null) {
            return "redirect:/";
        }

        Cart cart = getCart(session);

        if (!book.isSellable()) {
            return "redirect:/";
        }

        int quantityInCart = 0;
        for (CartItem item : cart.getItems()) {
            if (item.getBook().getId().equals(bookId)) {
                quantityInCart = item.getQuantity();
                break;
            }
        }
        

        if (book.getCopies() <= quantityInCart) {
            return "redirect:/";
        }

        cart.addItem(new CartItem(book, 1));
        session.setAttribute("cart", cart);
        return "redirect:/";
    }

    @PostMapping("/remove/{bookId}")
    public String removeFromCart(@PathVariable Integer bookId, HttpSession session) {
        if (!authService.isCustomerLoggedIn(session)) {
            return "redirect:/login";
        }
        Cart cart = getCart(session);
        cart.removeItem(bookId);
        session.setAttribute("cart", cart);
        return "redirect:/cart";
    }

    @PostMapping("/clear")
    public String clearCart(HttpSession session) {
        if (!authService.isCustomerLoggedIn(session)) {
            return "redirect:/login";
        }
        Cart cart = getCart(session);
        cart.clear();
        session.setAttribute("cart", cart);
        return "redirect:/cart";
    }

    @PostMapping("/update/{bookId}")
    public String updateQuantity(@PathVariable Integer bookId, @RequestParam int quantity, HttpSession session) {
        if (!authService.isCustomerLoggedIn(session)) {
            return "redirect:/login";
        }
        Cart cart = getCart(session);
        cart.updateItemQuantity(bookId, quantity);
        session.setAttribute("cart", cart);
        return "redirect:/cart";
    }

    private Cart getCart(HttpSession session) {
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }
        return cart;
    }
}
