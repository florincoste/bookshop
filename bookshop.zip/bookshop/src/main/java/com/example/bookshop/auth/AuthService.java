package com.example.bookshop.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bookshop.admin.Admin;
import com.example.bookshop.admin.AdminRepository;
import com.example.bookshop.customer.Customer;
import com.example.bookshop.customer.CustomerRepository;

import jakarta.servlet.http.HttpSession;

@Service
public class AuthService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private AdminRepository adminRepository;

    // Customer Authentication Methods
    public boolean authenticateCustomer(String email, String password) {
        Customer customer = customerRepository.findByEmail(email).orElse(null);
        return customer != null && customer.getPassword().equals(password);
    }

    public void setCustomerLogin(HttpSession session, String email) {
        session.setAttribute("user_logged_in", true);
        session.setAttribute("user_identifier", email);
    }

    public boolean isCustomerLoggedIn(HttpSession session) {
        Boolean loggedIn = (Boolean) session.getAttribute("user_logged_in");
        return loggedIn != null && loggedIn;
    }

    public String getLoggedInCustomerEmail(HttpSession session) {
        return (String) session.getAttribute("user_identifier");
    }

    public void logoutCustomer(HttpSession session) {
        session.removeAttribute("user_logged_in");
        session.removeAttribute("user_identifier");
        session.invalidate();
    }

    // Admin Authentication Methods
    public boolean authenticateAdmin(String username, String password) {
        Admin admin = adminRepository.findByUsername(username).orElse(null);
        return admin != null && admin.getPassword().equals(password);
    }

    public void setAdminLogin(HttpSession session, String username) {
        session.setAttribute("admin_logged_in", true);
        session.setAttribute("admin_username", username);
    }

    public boolean isAdminLoggedIn(HttpSession session) {
        Boolean loggedIn = (Boolean) session.getAttribute("admin_logged_in");
        return loggedIn != null && loggedIn;
    }

    public String getLoggedInAdminUsername(HttpSession session) {
        return (String) session.getAttribute("admin_username");
    }

    public void logoutAdmin(HttpSession session) {
        session.removeAttribute("admin_logged_in");
        session.removeAttribute("admin_username");
        session.invalidate();
    }

    public boolean isAnyUserLoggedIn(HttpSession session) {
        return isCustomerLoggedIn(session) || isAdminLoggedIn(session);
    }

    public void logoutAnyUser(HttpSession session) {
        session.invalidate();
    }
}
