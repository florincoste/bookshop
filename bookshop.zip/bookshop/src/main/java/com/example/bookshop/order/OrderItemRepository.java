package com.example.bookshop.order;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderItemRepository extends JpaRepository<OrderItem, Integer> {

    boolean existsByBook_Id(Integer bookId);

    List<OrderItem> findByBook_Id(Integer bookId);
}
