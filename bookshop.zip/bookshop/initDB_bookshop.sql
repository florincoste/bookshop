-- Drop and recreate database
-- DROP DATABASE IF EXISTS bookshop;
-- CREATE DATABASE bookshop;

USE bookshop;

-- Drop tables if they exist in the correct order due to FK dependencies
DROP TABLE IF EXISTS `order_items`;
DROP TABLE IF EXISTS `order`;
DROP TABLE IF EXISTS `customer`;
DROP TABLE IF EXISTS `book`;
DROP TABLE IF EXISTS `admin`;

-- Create admin table
CREATE TABLE `admin` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL
);

-- Create book table
CREATE TABLE `book` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(255) NOT NULL,
    `author` VARCHAR(255) NOT NULL,
    `year` INT NOT NULL,
    `price` DECIMAL(10,2) NOT NULL,
    `copies` INT NOT NULL,
    `sellable` BOOLEAN NOT NULL
);

-- Create customer table
CREATE TABLE `customer` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `surname` VARCHAR(100) NOT NULL,
    `date_of_birth` DATE NOT NULL,
    `address` VARCHAR(255) NOT NULL,
    `phone` VARCHAR(30) NOT NULL,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL
);

-- Create order table
CREATE TABLE `order` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `customer_id` INT NOT NULL,
    `payment_status` ENUM('success','failed') NOT NULL,
    `amount` DECIMAL(10,2) NOT NULL,
    `order_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`customer_id`) REFERENCES `customer`(`id`)
);

-- Create order_items table
CREATE TABLE `order_items` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_id` INT NOT NULL,
    `book_id` INT NOT NULL,
    `quantity` INT NOT NULL,
    FOREIGN KEY (`order_id`) REFERENCES `order`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`book_id`) REFERENCES `book`(`id`)
);

-- Insert mock admin
INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- Insert mock books
INSERT INTO `book` (`title`, `author`, `year`, `price`, `copies`, `sellable`) VALUES
('Effective Java', 'Joshua Bloch', 2018, 45.00, 10, true),
('Clean Code', 'Robert C. Martin', 2008, 40.00, 5, true),
('Spring in Action', 'Craig Walls', 2022, 50.00, 8, true),
('Domain-Driven Design', 'Eric Evans', 2003, 55.00, 6, true),
('Refactoring', 'Martin Fowler', 2012, 38.00, 4, true),
('Head First Design Patterns', 'Eric Freeman', 2004, 42.00, 7, true),
('Example Book', 'Joe Doe', 2025, 0, 0, false);

-- Insert mock customers
INSERT INTO `customer` (`name`, `surname`, `date_of_birth`, `address`, `phone`, `email`, `password`) VALUES
('Alice', 'Smith', '1990-05-21', '123 Main Street, Dublin', '0851234567', 'asmith@example.com', 'Alice123'),
('Bob', 'Johnson', '1985-12-12', '456 Oak Road, Cork', '0867654321', 'bob@example.com', 'Bob123');

-- Insert mock orders with randomized time in last week
INSERT INTO `order` (`customer_id`, `payment_status`, `amount`, `order_date`)
VALUES (1, 'success', 85.00, NOW() - INTERVAL FLOOR(RAND() * 604800) SECOND);

INSERT INTO `order` (`customer_id`, `payment_status`, `amount`, `order_date`)
VALUES (1, 'failed', 50.00, NOW() - INTERVAL FLOOR(RAND() * 604800) SECOND);

INSERT INTO `order` (`customer_id`, `payment_status`, `amount`, `order_date`)
VALUES (2, 'success', 135.00, NOW() - INTERVAL FLOOR(RAND() * 604800) SECOND);

-- Insert mock order_items
INSERT INTO `order_items` (`order_id`, `book_id`, `quantity`) VALUES
(1, 1, 1), -- Alice bought 1x Effective Java
(1, 2, 1), -- Alice bought 1x Clean Code
(2, 3, 1), -- Alice attempted to buy 1x Spring in Action (failed order)
(3, 4, 1), -- Bob bought 1xDomain-Driven Design
(3, 5, 2), -- Bob bought 2x Refactoring
(3, 6, 1); -- Bob bought 1x Head First
