# Assignment 1: BookShop Project

## Project Description

Simplified online bookstore application called **BookShop** using Spring Boot. The project focuses on implementing core features such as browsing books, managing a shopping cart, and placing mock orders. Security aspects are **not** a focus for this assignment.

---

## Project Requirements

### Summary of Functional Requirements

#### Admin Functionalities

- **Log in and log out** of the system  
  (Admins use pre-defined usernames and passwords; **no admin registration required**.)
- **Add, edit, and delete books** (Admin logged in is required)
  Each book includes: title, author, year, price, and number of copies

#### Customer Functionalities

- **Register** in the BookShop  
  Customer provides name, surname, date of birth, address, phone number, email address
- **Log in and log out** of the system
- **Browse available books**  
  Accessible to *any* user, even when not logged in
- **Add books to cart** (logged in required)
- **View the cart** (logged in required)
  Contains items, prices, total price
- **Remove items from cart** (logged in required)
- **Place an order** (logged in required) 
  - Must have at least one item in cart:  
  - Customer provides payment details (e.g., credit card number)
  - Success message is printed.  
  - No verification or storage of payment details is required.
  - Orders and credit card numbers do not need to be stored in the database.

### Summary of Technical Requirements

- Use **Spring Boot** (Java).
- Use **MySQL** as the database.
- Use **Thymeleaf** (or optionally React) for the frontend.  
  (Thymeleaf example will be provided in tutorial materials.)
- **No requirements concerning the graphical user interface**—any clean design is acceptable.
- **Security is not a focus** for this assignment.

---

## Project Package Structure 

```text
com.example.bookshop
|
|-- home/                        // Controllers and logic for the homepage and main book listing
|   |-- HomeController.java      // Handles homepage, shows book list, login form, cart button
|
|-- admin/                       // Admin management: login, dashboard, book/customer/order admin
|   |-- AdminController.java     // Handles admin login, logout, and book/customer/order management
|   |-- Admin.java               // Admin entity (id, username, password)
|   |-- AdminRepository.java     // Spring Data repository for admins
|
|-- auth/                        // Authentication helpers for templates and session
|   |-- AuthAdvice.java          // Provides authentication status to Thymeleaf templates
|   |-- AuthService.java         // Shared login/logout logic for both customers and admin
|
|-- book/                        // Book domain: entities, repositories, services
|   |-- Book.java                // Book entity (id, title, author, year, price, copies, sellable)
|   |-- BookRepository.java      // Spring Data repository for books
|   |-- BookService.java         // Book-related business logic
|
|-- customer/                    // Customer domain: registration, login, persistence
|   |-- CustomerController.java  // Handles registration, login, logout for customers
|   |-- Customer.java            // Customer entity (id, name, surname, dateOfBirth, address, phone, email, password, orders)
|   |-- CustomerRepository.java  // Spring Data repository for customers
|   |-- CustomerService.java     // (Unused) Customer-related business logic
|
|-- cart/                        // Shopping cart logic, session storage, and Thymeleaf helpers
|   |-- CartController.java      // Handles viewing, adding, removing, clearing books in cart
|   |-- CartAdvice.java          // Provides cart item count for display in the navbar
|   |-- Cart.java                // Cart object: holds list of CartItem, calculates total price/quantity
|   |-- CartItem.java            // Represents an item in the cart (book, quantity)
|
|-- order/                       // Order placement and order history for customers
|   |-- OrderController.java     // Handles placing and viewing orders
|   |-- Order.java               // Order entity (id, customer, paymentStatus, amount, orderDate, orderItems)
|   |-- OrderItem.java           // OrderItem entity (id, order, book, quantity)
|   |-- OrderRepository.java     // Spring Data repository for orders
|   |-- OrderItemRepository.java // Spring Data repository for order items
|
|-- error/                       // Global and custom exception handling
|   |-- GlobalExceptionHandler.java     // Handles exceptions globally across the application
|   |-- ResourceNotFoundException.java  // Custom exception for handling missing resources
|
|-- config/                      // (unused) For future expansion of web or security configuration (e.g., view resolvers)
|
|-- BookshopApplication.java     // The main Spring Boot application class
```

---

### Entity Fields List

- **Admin**
  - `id`: unique identifier (auto-increment)
  - `username`: admin login name (unique)
  - `password`: admin password

- **Book**
  - `id`: unique identifier (auto-increment)
  - `title`: title of the book
  - `author`: author of the book
  - `year`: year of publication
  - `price`: book price
  - `copies`: number of available copies
  - `sellable`: boolean indicating if the book can be sold

- **Customer**
  - `id`: unique identifier (auto-increment)
  - `name`: customer's first name
  - `surname`: customer's last name
  - `dateOfBirth`: date of birth
  - `address`: postal address
  - `phone`: contact number
  - `email`: email/username (unique)
  - `password`: password
  - `orders`: list of orders placed by the customer

- **Order**
  - `id`: unique identifier (auto-increment)
  - `customer`: reference to the customer who placed the order
  - `paymentStatus`: can be `'success'` or `'failed'`
  - `amount`: total order amount
  - `orderDate`: date and time when the order was placed
  - `orderItems`: list of items in the order

- **OrderItem**
  - `id`: unique identifier (auto-increment)
  - `order`: reference to the related order
  - `book`: reference to the purchased book
  - `quantity`: number of copies of the book in the order

- **Cart**
  - `items`: list of CartItem objects
  - `totalPrice`: computed total price of all items in the cart
  - `totalQuantity`: computed total quantity of all items in the cart

- **CartItem**
  - `book`: the book being added to the cart
  - `quantity`: number of copies of the book in the cart

---

### Database Tables & Data Structures

#### **Admin** (table)
- **Purpose:** Stores administrator account information for managing the bookstore.
- **Fields:**
  - `id` — unique identifier (auto-increment)
  - `username` — admin login name (unique)
  - `password` — admin password (plain text ~~hashed~~)

#### **Book** (table)
- **Purpose:** Stores all books available in the bookstore.
- **Fields:**
  - `id` — unique identifier (auto-increment)
  - `title` — title of the book
  - `author` — author of the book
  - `year` — year of publication
  - `price` — book price
  - `copies` — number of available copies
  - `sellable` — boolean indicating if the book can be sold

#### **Customer** (table)
- **Purpose:** Stores registered customer information.
- **Fields:**
  - `id` — unique identifier (auto-increment)
  - `name` — customer's first name
  - `surname` — customer's last name
  - `date_of_birth` — date of birth
  - `address` — postal address
  - `phone` — contact number
  - `email` — email/username (unique)
  - `password` — password (unique)

#### **Order** (table)
- **Purpose:** Stores information about orders placed by customers.
- **Fields:**
  - `id` — unique identifier (auto-increment)
  - `customer_id` — references the customer id who placed the order
  - `payment_status` — can be `'success'` or `'failed'`
  - `amount` — total order amount
  - `order_date` — date and time when the order was placed

#### **Order_Items** (table)
- **Purpose:** Stores details of books included in each order (enables multiple books per order).
- **Fields:**
  - `id` — unique identifier (auto-increment)
  - `order_id` — references the related order id
  - `book_id` — references the purchased book id
  - `quantity` — number of copies of the book in the order

---


## Page & Controller Routing Map

Below is a summary of the main pages in the BookShop application and a simple map showing which controller and route renders or redirects to each page.

### Main Pages

| Page Template           | Route/URL                       | Controller & Method                        | Notes                                 |
|------------------------ |---------------------------------|--------------------------------------------|---------------------------------------|
| `home.html`             | `/`                             | `HomeController#home`                      | Book listing, homepage                |
| `login.html`            | `/login`                        | `CustomerController#loginPage`             | Customer login                        |
| `register.html`         | `/register`                     | `CustomerController#registerPage`          | Customer registration                 |
| `cart.html`             | `/cart`                         | `CartController#viewCart`                  | View cart (login required)            |
| `checkout.html`         | `/checkout`                     | `OrderController#showCheckout`             | Checkout form (login required)        |
| `order-success.html`    | `/order/success/{orderId}`      | `OrderController#orderSuccess`             | Order placed, shows order details     |
| `order-failed.html`     | `/order/failed`                 | `OrderController#orderFailed`              | Order failed/error page               |
| `admin/login.html`      | `/admin/login`                  | `AdminController#loginPage`                | Admin login                           |
| `admin/dashboard.html`  | `/admin/dashboard`              | `AdminController#dashboard`                | Admin dashboard                       |
| `admin/book-add.html`   | `/admin/books/add`              | `AdminController#addBookForm`              | Add book (admin)                      |
| `admin/book-edit.html`  | `/admin/books/edit/{id}`        | `AdminController#editBookForm`             | Edit book (admin)                     |
| `admin/customer-view.html` | `/admin/customers/view/{id}` | `AdminController#viewCustomer`             | View customer (admin)                 |
| `admin/customer-edit.html` | `/admin/customers/edit/{id}` | `AdminController#editCustomerForm`         | Edit customer (admin)                 |
| `admin/order-view.html` | `/admin/orders/view/{id}`       | `AdminController#viewOrder`                | View order (admin)                    |

### Redirect & Flow Map

```text
[home.html]           <-- GET / (HomeController)
[login.html]          <-- GET /login (CustomerController)
[register.html]       <-- GET /register (CustomerController)
[cart.html]           <-- GET /cart (CartController, login required)
[checkout.html]       <-- GET /checkout (OrderController, login required)
[order-success.html]  <-- GET /order/success?orderId=... (OrderController, login required, order owner only)
[order-failed.html]   <-- GET /order/failed (OrderController)
[admin/login.html]    <-- GET /admin/login (AdminController)
[admin/dashboard.html]<-- GET /admin/dashboard (AdminController)
[admin/book-add.html] <-- GET /admin/books/add (AdminController)
[admin/book-edit.html]<-- GET /admin/books/edit/{id} (AdminController)
[admin/customer-view.html] <-- GET /admin/customers/view/{id} (AdminController)
[admin/customer-edit.html] <-- GET /admin/customers/edit/{id} (AdminController)
[admin/order-view.html] <-- GET /admin/orders/view/{id} (AdminController)
```

---

### Main Pages and Routes

- **Home**
  - `GET /` -> `home.html`  
    *Handled by:* `HomeController#home`

- **Login/Logout/Registration (Customer)**
  - `GET /login` -> `login.html`  
    *Handled by:* `CustomerController#loginPage`
  - `POST /login` -> redirects to `/` (home) on success, or `login.html` on failure  
    *Handled by:* `CustomerController#login`
  - `GET /logout` -> redirects to `/` (home)  
    *Handled by:* `CustomerController#logout`
  - `GET /register` -> `register.html`  
    *Handled by:* `CustomerController#registerPage`
  - `POST /register` -> redirects to `/login` on success, or `register.html` on failure  
    *Handled by:* `CustomerController#register`

- **Cart**
  - `GET /cart` -> `cart.html` (login required)  
    *Handled by:* `CartController#viewCart`
  - `POST /cart/add/{bookId}` -> redirects to `/` (login required)  
    *Handled by:* `CartController#addToCart`
  - `POST /cart/remove/{bookId}` -> redirects to `/cart` (login required)  
    *Handled by:* `CartController#removeFromCart`
  - `POST /cart/clear` -> redirects to `/cart`  
    *Handled by:* `CartController#clearCart`
  - `POST /cart/update/{bookId}` -> redirects to `/cart`  
    *Handled by:* `CartController#updateCartItem`

- **Checkout & Orders**
  - `GET /checkout` -> `checkout.html` (login required)  
    *Handled by:* `OrderController#showCheckout`
  - `POST /checkout` -> redirects to `/order/success?orderId=...` on success, or `checkout.html` on validation error  
    *Handled by:* `OrderController#placeOrder`
  - `GET /order/success?orderId=...` -> `order-success.html` (only if order belongs to logged-in user)  
    *Handled by:* `OrderController#orderSuccess`
  - `GET /order/failed` -> `order-failed.html`  
    *Handled by:* `OrderController#orderFailed`

- **Admin**
  - `GET /admin/login` -> `admin/login.html`  
    *Handled by:* `AdminController#loginPage`
  - `POST /admin/login` -> redirects to `/admin/dashboard` on success, or `admin/login.html` on failure  
    *Handled by:* `AdminController#login`
  - `GET /admin/logout` -> redirects to `/admin/login`  
    *Handled by:* `AdminController#logout`
  - `GET /admin/dashboard` -> `admin/dashboard.html`  
    *Handled by:* `AdminController#dashboard`
  - `GET /admin/books/add` -> `admin/book-add.html`  
    *Handled by:* `AdminController#addBookForm`
  - `POST /admin/books/add` -> redirects to `/admin/dashboard` or shows errors  
    *Handled by:* `AdminController#addBook`
  - `GET /admin/books/edit/{id}` -> `admin/book-edit.html`  
    *Handled by:* `AdminController#editBookForm`
  - `POST /admin/books/edit/{id}` -> redirects to `/admin/dashboard` or shows errors  
    *Handled by:* `AdminController#editBook`
  - `GET /admin/customers/view/{id}` -> `admin/customer-view.html`  
    *Handled by:* `AdminController#viewCustomer`
  - `GET /admin/customers/edit/{id}` -> `admin/customer-edit.html`  
    *Handled by:* `AdminController#editCustomerForm`
  - `POST /admin/customers/edit/{id}` -> redirects to `/admin/dashboard` or shows errors  
    *Handled by:* `AdminController#editCustomer`
  - `GET /admin/orders/view/{id}` -> `admin/order-view.html`  
    *Handled by:* `AdminController#viewOrder`

- **Error Handling**
  - Any unhandled exception -> `error.html`  
    *Handled by:* `GlobalExceptionHandler`
  - Resource not found (404) -> `error.html`  
    *Handled by:* `GlobalExceptionHandler` or Spring Boot default

---


### Main Pages and Routes

- **Home**
  - `GET /` -> `home.html`  
    *Handled by:* `HomeController#home`

- **Login/Logout/Registration (Customer)**
  - `GET /login` -> `login.html`  
    *Handled by:* `CustomerController#loginPage`
  - `POST /login` -> redirects to `/` (home) on success, or `login.html` on failure  
    *Handled by:* `CustomerController#login`
  - `GET /logout` -> redirects to `/` (home)  
    *Handled by:* `CustomerController#logout`
  - `GET /register` -> `register.html`  
    *Handled by:* `CustomerController#registerPage`
  - `POST /register` -> redirects to `/login` on success, or `register.html` on failure  
    *Handled by:* `CustomerController#register`

- **Cart**
  - `GET /cart` -> `cart.html` (login required)  
    *Handled by:* `CartController#viewCart`
  - `POST /cart/add/{bookId}` -> redirects to `/` (login required)  
    *Handled by:* `CartController#addToCart`
  - `POST /cart/remove/{bookId}` -> redirects to `/cart` (login required)  
    *Handled by:* `CartController#removeFromCart`
  - `POST /cart/clear` -> redirects to `/cart`  
    *Handled by:* `CartController#clearCart`
  - `POST /cart/update/{bookId}` -> redirects to `/cart`  
    *Handled by:* `CartController#updateCartItem`

- **Checkout & Orders**
  - `GET /checkout` -> `checkout.html` (login required)  
    *Handled by:* `OrderController#showCheckout`
  - `POST /checkout` -> redirects to `/order/success?orderId=...` on success, or `checkout.html` on validation error  
    *Handled by:* `OrderController#placeOrder`
  - `GET /order/success?orderId=...` -> `order-success.html` (only if order belongs to logged-in user)  
    *Handled by:* `OrderController#orderSuccess`
  - `GET /order/failed` -> `order-failed.html`  
    *Handled by:* `OrderController#orderFailed`

- **Admin**
  - `GET /admin/login` -> `admin/login.html`  
    *Handled by:* `AdminController#loginPage`
  - `POST /admin/login` -> redirects to `/admin/dashboard` on success, or `admin/login.html` on failure  
    *Handled by:* `AdminController#login`
  - `GET /admin/logout` -> redirects to `/admin/login`  
    *Handled by:* `AdminController#logout`
  - `GET /admin/dashboard` -> `admin/dashboard.html`  
    *Handled by:* `AdminController#dashboard`
  - `GET /admin/books/add` -> `admin/book-add.html`  
    *Handled by:* `AdminController#addBookForm`
  - `POST /admin/books/add` -> redirects to `/admin/dashboard` or shows errors  
    *Handled by:* `AdminController#addBook`
  - `GET /admin/books/edit/{id}` -> `admin/book-edit.html`  
    *Handled by:* `AdminController#editBookForm`
  - `POST /admin/books/edit/{id}` -> redirects to `/admin/dashboard` or shows errors  
    *Handled by:* `AdminController#editBook`
  - `GET /admin/customers/view/{id}` -> `admin/customer-view.html`  
    *Handled by:* `AdminController#viewCustomer`
  - `GET /admin/customers/edit/{id}` -> `admin/customer-edit.html`  
    *Handled by:* `AdminController#editCustomerForm`
  - `POST /admin/customers/edit/{id}` -> redirects to `/admin/dashboard` or shows errors  
    *Handled by:* `AdminController#editCustomer`
  - `GET /admin/orders/view/{id}` -> `admin/order-view.html`  
    *Handled by:* `AdminController#viewOrder`

- **Error Handling**
  - Any unhandled exception -> `error.html`  
    *Handled by:* `GlobalExceptionHandler`
  - Resource not found (404) -> `error.html`  
    *Handled by:* `GlobalExceptionHandler` or Spring Boot default

---


### Notes

- All cart and order operations require the user to be logged in.
- Order details are only visible to the customer who placed the order.
- Admin pages are only accessible to logged-in admins.
- All redirects and error pages are handled as described above.

---

Here are the sections ready to paste into your readme.md file:

---

## Session & Authentication Flow

- **Customer Authentication:**  
  - On login, sets `user_logged_in=true` and `user_identifier` (customer email) in session.
  - On logout, these attributes are removed and session is invalidated.
- **Admin Authentication:**  
  - On login, sets `admin_logged_in=true` and `admin_username` in session.
  - On logout, these attributes are removed and session is invalidated.
- **Cart Storage:**  
  - The cart is stored in the session as the `cart` attribute and is unique per user session.
- **Session Expiry:**  
  - If the session expires, users must log in again and the cart will be reset.

---

## Cart & Order Logic

- **Cart:**  
  - Users add books to the cart from the homepage.
  - Cart is session-based and not persisted in the database.
  - Users can update quantities, remove items, or clear the cart.
- **Checkout:**  
  - Only logged-in users can access checkout.
  - On successful order, an `Order` and related `OrderItem` records are created in the database.
  - Cart is cleared after a successful order.
  - Payment details are validated but not stored.

---

## Access Control Summary

| Feature/Page         | Guest | Customer | Admin  |
|----------------------|:-----:|:--------:|:------:|
| Home/book listing    |  ✔    |   ✔      |   ✔    |
| Register/Login       |  ✔    |   ✔      |   ✖    |
| Cart/Checkout        |  ✖    |   ✔      |   ✖    |
| Order history        |  ✖    |   ✔      |   ✖    |
| Admin dashboard      |  ✖    |   ✖      |   ✔    |
| Manage books/orders  |  ✖    |   ✖      |   ✔    |

- Unauthorized access redirects to login or home as appropriate.

---

## Error Handling

- **Global Exception Handling:**  
  - All unhandled exceptions are caught by `GlobalExceptionHandler` and shown on `error.html`.
  - In development mode (`spring.profiles.active=dev`), stack traces are shown.
  - 404 errors are handled with a user-friendly message.
- **Order/Cart Errors:**  
  - Invalid or empty cart, or unauthorized order access, redirects to error or home page with a message.

---

## Data Validation Rules

- **Registration:**  
  - All fields required; email must be unique.
- **Login:**  
  - Email and password required.
- **Checkout:**  
  - Credit card: 16 digits, spaces/dashes allowed.
  - Expiry: MM/YY format.
  - CVV: 3 or 4 digits.
- **Cart:**  
  - Quantity cannot exceed available copies.

---

## Limitations & Security Notes

- **Passwords** are stored in plain text (for demo only).
- **No password reset, email verification, or account lockout.**
- **No CSRF/XSS protection**; not suitable for production.
- **Cart is not persisted**; lost on logout/session expiry.
- **Payment details are not stored or verified.**

---

## Setup & Testing Instructions

1. **Clone the repository.**
2. **Configure MySQL:**  
   - Create a database named `bookshop`.
   - Update application.properties with your DB credentials.
3. **Insert Sample Data:**  
   - Use the SQL below to populate the database with test accounts and data.
4. **Run the application:**  
   - In the project root:  
     ```
     ./mvnw spring-boot:run
     ```
     or  
     ```
     mvn spring-boot:run
     ```
5. **Access the app:**  
   - Customer: [http://localhost:8080/](http://localhost:8080/)
   - Admin: [http://localhost:8080/admin/login](http://localhost:8080/admin/login)


---

## Sample Data & Test Accounts

```sql
-- Insert mock admin
INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- Insert mock books
INSERT INTO `book` (`title`, `author`, `year`, `price`, `copies`, `sellable`) VALUES
('Effective Java', 'Joshua Bloch', 2018, 45.00, 10, true),
('Clean Code', 'Robert C. Martin', 2008, 40.00, 5, true),
('Spring in Action', 'Craig Walls', 2022, 50.00, 8, true),
('Domain-Driven Design', 'Eric Evans', 2003, 55.00, 6, true),
('Refactoring', 'Martin Fowler', 2012, 38.00, 4, true),
('Head First Design Patterns', 'Eric Freeman', 2004, 42.00, 7, true),
('Example Book', 'Joe Doe', 2025, 0, 0, false);

-- Insert mock customers
INSERT INTO `customer` (`name`, `surname`, `date_of_birth`, `address`, `phone`, `email`, `password`) VALUES
('Alice', 'Smith', '1990-05-21', '123 Main Street, Dublin', '0851234567', 'asmith@example.com', 'Alice123'),
('Bob', 'Johnson', '1985-12-12', '456 Oak Road, Cork', '0867654321', 'bob@example.com', 'Bob123');

-- Insert mock orders with randomized time in last week
INSERT INTO `order` (`customer_id`, `payment_status`, `amount`, `order_date`)
VALUES (1, 'success', 85.00, NOW() - INTERVAL FLOOR(RAND() * 604800) SECOND);

INSERT INTO `order` (`customer_id`, `payment_status`, `amount`, `order_date`)
VALUES (1, 'failed', 50.00, NOW() - INTERVAL FLOOR(RAND() * 604800) SECOND);

INSERT INTO `order` (`customer_id`, `payment_status`, `amount`, `order_date`)
VALUES (2, 'success', 135.00, NOW() - INTERVAL FLOOR(RAND() * 604800) SECOND);

-- Insert mock order_items
INSERT INTO `order_items` (`order_id`, `book_id`, `quantity`) VALUES
(1, 1, 1), -- Alice bought 1x Effective Java
(1, 2, 1), -- Alice bought 1x Clean Code
(2, 3, 1), -- Alice attempted to buy 1x Spring in Action (failed order)
(3, 4, 1), -- Bob bought 1x Domain-Driven Design
(3, 5, 2), -- Bob bought 2x Refactoring
(3, 6, 1); -- Bob bought 1x Head First
```

**Test Accounts:**
- Admin:  
  - Username: `admin`  
  - Password: `admin`
- Customer:  
  - Email: `asmith@example.com`  
  - Password: `Alice123`  
  - Email: `bob@example.com`  
  - Password: `Bob123`

---

## Screenshots or UI Walkthrough

*Add screenshots of the main pages (home, cart, checkout, admin dashboard, etc.) here to illustrate the user experience.*

---